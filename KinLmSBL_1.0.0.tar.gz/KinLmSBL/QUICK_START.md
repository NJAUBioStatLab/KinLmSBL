# KinLmSBL Quick Start Guide

## Step 1: Install Package

### Option 1: Install from Source (Recommended)
```r
# 1. First install dependencies
install.packages(c("rMVP", "data.table", "Matrix", "doParallel", 
                   "Rcpp", "RcppArmadillo", "RcppEigen"))

# 2. Install KinLmSBL package
# Method A: Using install.packages
setwd("d:/KinLmSBL_1.0.0")
install.packages("KinLmSBL", repos = NULL, type = "source")

# Method B: Using devtools
devtools::install("d:/KinLmSBL_1.0.0/KinLmSBL")
```

### Option 2: Using R CMD Build
```bash
# Execute in PowerShell or command line
cd d:\KinLmSBL_1.0.0
R CMD build KinLmSBL
R CMD INSTALL KinLmSBL_1.0.0.tar.gz
```

## Step 2: Load Package and Run Example

```r
# Load package
library(KinLmSBL)

# Set working directory to where data files are located
setwd("your/data/directory")

# Run GWAS analysis
result <- KinLmSBL(
  Y = "phenotype.csv",        # Phenotype file
  GD = "genotype.012.csv",    # Genotype file (012 format)
  KI = "kinship.csv",         # Kinship matrix
  CV = "covariates.csv",      # Covariate file (e.g., PCs)
  file.output = TRUE,         # Save results to file
  dir = getwd()               # Output directory
)


# View results
print(result)

# If significant SNPs are found
if(nrow(result) > 0) {
  # View first few significant SNPs
  head(result)
  
  # Sort by P-value
  result_sorted <- result[order(result$P.value), ]
  print(result_sorted)
  
  # View SNPs with highest variance explained
  result_r2 <- result[order(result$`r2(%)`, decreasing = TRUE), ]
  print(result_r2)
} else {
  message("No significant SNPs found")
}
```


## Data Format Examples

### 1. Phenotype File (phe.csv)
```
ID,Trait
Ind1,12.5
Ind2,15.3
Ind3,10.8
...
```

### 2. Genotype File (snp.all.012.csv)
```
SNP,Chr,Pos,Ref,Ind1,Ind2,Ind3,...
SNP1,1,1000,A,0,1,2,...
SNP2,1,2000,T,1,1,0,...
...
```

### 3. Kinship Matrix (kk.csv)
```
Ind1,Ind2,Ind3,...
1.0,0.5,0.2,...
0.5,1.0,0.3,...
0.2,0.3,1.0,...
...
```

### 4. Covariate File (fixedpc.csv)
```
ID,PC1,PC2,PC3
Ind1,0.1,0.2,0.3
Ind2,0.2,0.1,0.4
Ind3,0.3,0.3,0.2
...
```

## Frequently Asked Questions

### Q1: What if I get compilation errors?
A: Make sure Rtools (Windows) or compilation toolchain (Linux/Mac) is installed

### Q2: No significant SNPs found?
A: This is normal. Possible reasons:
- Insufficient sample size
- Weak association between phenotype and genotype
- Need to adjust significance threshold

### Q3: Out of memory?
A: For large datasets, you can:
```r
# Increase R memory limit (Windows)
memory.limit(size = 16000)

# Or process data in batches
```

### Q4: How to view help?
```r
?KinLmSbl
help(package = "KinLmSBL")
```

## More Information

- See `README.md` for detailed package information
- See `INSTALLATION.md` for complete installation and configuration steps
- Use `?KinLmSbl` to view function help documentation

## Citation

If you use this package, please cite:

- Zhang et al.(2025). Integrated single marker scanning and sparse Bayesian learning
improves performance of detection for GWAS

- Wang & Xu. (2019). A coordinate descent approach for sparse Bayesian learning in high dimensional QTL mapping and genome-wide association studies. Bioinformatics, 35(21), 4327–4335. https://doi.org/10.1093/bioinformatics/btz244

- Wen et al. (2018). Methodological implementation of mixed linear models in multi-locus genome-wide association studies. Briefings in bioinformatics, 19(4), 700–712. https://doi.org/10.1093/bib/bbw145
