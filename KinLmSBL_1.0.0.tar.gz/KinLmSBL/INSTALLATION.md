# KinLmSBL Package Installation and Usage Guide

## Package Structure

KinLmSBL is an R package that implements a GWAS method combining linear mixed models with kinship correction and sparse Bayesian learning.

### Directory Structure
```
KinLmSBL/
├── DESCRIPTION          # Package description file (including dependencies)
├── NAMESPACE            # Namespace file
├── README.md            # Package documentation
├── R/                   # R source code
│   ├── KinLmSbl.R      # Main function
│   └── emma_REMLE.R    # variance components from FASTmrEMMA (Wen et al.,2018) and Package gaston
├── src/                 # C++ source code
│   ├── sbl.cpp         # Sparse Bayesian Learning
│   ├── kinCorrect.cpp  # Kinship correction
│   ├── lmm_diago_fit.cpp  # Linear mixed model
│   ├── matrix-varia.cpp   # Matrix operations
│   ├── *.h             # Header files
│   ├── Makevars        # Unix compilation configuration
│   └── Makevars.win    # Windows compilation configuration
└── man/                 # Help documentation
    ├── KinLmSBL-package.Rd
    └── KinLmSbl.Rd
```

## Dependencies

This package depends on the following R packages (declared in DESCRIPTION file):

### Required Packages (Imports):
- **rMVP**: a memory-efficient and parallel-accelerated R package that integrates the FarmCPU method
- **data.table**: Efficient data reading
- **Matrix**: Sparse matrix operations
- **doParallel**: Parallel computing
- **Rcpp** (>= 0.12.0): R and C++ interface
- **RcppArmadillo**: Armadillo linear algebra library
- **RcppEigen**: Eigen linear algebra library

### linked library (LinkingTo)：
- Rcpp
- RcppArmadillo
- RcppEigen

## Installation Steps

### 1. Install Dependencies

Run in R:
```r
# Install CRAN packages
install.packages(c("data.table", "Matrix", "doParallel", 
                   "Rcpp", "RcppArmadillo", "RcppEigen"))

# Install rMVP (if not installed)
if (!require("rMVP")) {
  install.packages("rMVP")
}

### 2. Build and Install Package

#### Method 1: Using RStudio
1. Open RStudio
2. Open the KinLmSBL.Rproj project file
3. Click Build > Install and Restart

#### Method 2: Using Command Line
```r
# Run in R
setwd("d:/KinLmSBL_1.0.0")
install.packages("KinLmSBL", repos = NULL, type = "source")
```

#### Method 3: Using devtools
```r
# Install devtools (if not already installed)
install.packages("devtools")

# Install package
devtools::install("d:/KinLmSBL_1.0.0/KinLmSBL")
```

#### Method 4: Using R CMD (in terminal)
```bash
# Windows PowerShell
cd d:\KinLmSBL_1.0.0
R CMD build KinLmSBL
R CMD INSTALL KinLmSBL_1.0.0.tar.gz
```

## Usage Instructions

### 1. Load Package
```r
library(KinLmSBL)
```

### 2. Prepare Data

#### Phenotype File (phenotype.csv)
```
ID,Trait
Ind1,12.5
Ind2,15.3
Ind3,10.8
...
```

#### Genotype File (genotype.012.csv)
```
SNP,Chr,Pos,Ref,Ind1,Ind2,Ind3,...
SNP1,1,1000,A,0,1,2,...
SNP2,1,2000,T,1,1,0,...
...
```

#### Kinship Matrix (kinship.csv)
```
Ind1,Ind2,Ind3,...
1.0,0.5,0.2,...
0.5,1.0,0.3,...
0.2,0.3,1.0,...
...
```

#### Covariate File (covariates.csv)
```
ID,PC1,PC2,PC3
Ind1,0.1,0.2,0.3
Ind2,0.2,0.1,0.4
Ind3,0.3,0.3,0.2
...
```

### 3. Run Analysis
```r
result <- KinLmSbl(
  Y = "phenotype.csv",
  GD = "genotype.012.csv",
  KI = "kinship.csv",
  CV = "covariates.csv",
  file.output = TRUE,
  dir = getwd()
)

# View results
print(result)
head(result)
```

### 4. Result Interpretation

The output data frame contains the following columns:
- **SNP**: SNP id
- **Chr**: Chromosome 
- **Pos**: Position on chromosome
- **P.value**: FDR-adjusted p-value
- **MAF**: Minor allele frequency
- **r2(%)**: Variance explained by the SNP
- **Effect**: Effect size

## Two-Stage Analysis Method

### First Stage: 
In the first stage, it constructs a mixed linear model and corrects for the polygenic background using FASTmrEMMA's matrix transformation. It then employs rMVP's MVP.GLM function to scan high-throughput SNPs, screening for a small number of potentially associated SNPs for the next stage. 

### Second Stage: 
In the second stage, it constructs a hierarchical linear model, applies the SBL algorithm to estimate marker effects and construct the Wald test statistic, and implements FDR correction. Eventually, significant loci related to the trait are identified.

## System Requirements

- R >= 3.5.0
- C++11 compiler
- Windows: Rtools
- Linux/Mac: g++ or clang++

## Troubleshooting

### Issue 1: Compilation Errors
Ensure Rtools (Windows) or g++ (Linux/Mac) is installed

### Issue 2: Missing Dependencies
Run `install.packages()` to install all dependencies

### Issue 3: Out of Memory
For large datasets, increase R memory limit:
```r
memory.limit(size = 16000)  # Windows
```

## References

- Zhang et al.(2025). Integrated single marker scanning and sparse Bayesian learning
improves performance of detection for GWAS


## Contact

For questions, please contact: 

## License

GPL (>= 2)

## Author

Designed by Yangjun Wen
Written by Zhenghan Wu, Gang Han, Mingzhi Cai, and Jin Zhang
