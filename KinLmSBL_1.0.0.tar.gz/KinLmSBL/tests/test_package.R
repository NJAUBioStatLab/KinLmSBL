# KinLmSBL Package Test Script
# Used to test if the package is installed and running correctly

# ==================================
# 1. Check if the package is installed
# ==================================
if (!require("KinLmSBL")) {
  stop("KinLmSBL package is not installed. Please install the package first.")
} else {
  cat("✓ KinLmSBL package loaded successfully\n")
}

# ==================================
# 2. Check dependent packages
# ==================================
cat("\nChecking dependent packages...\n")
required_packages <- c("rMVP", "data.table", "Matrix", "doParallel", 
                       "Rcpp", "RcppArmadillo", "RcppEigen")

for (pkg in required_packages) {
  if (require(pkg, character.only = TRUE, quietly = TRUE)) {
    cat("✓", pkg, "is installed\n")
  } else {
    cat("✗", pkg, "is not installed\n")
  }
}

# ==================================
# 3. View help documentation
# ==================================
cat("\nViewing help documentation...\n")
cat("Run: ?KinLmSbl to view function help\n")
cat("Run: help(package='KinLmSBL') to view package help\n")

# ==================================
# 4. Test run (using actual data)
# ==================================
cat("\nStarting test run...\n")

# Set data file paths
# Modify these paths according to the actual situation
Y_file <- "phe.csv"
GD_file <- "snp.all.012.csv"
KI_file <- "kk.csv"
CV_file <- "fixedpc.csv"

# Check if files exist
files_exist <- all(file.exists(c(Y_file, GD_file, KI_file, CV_file)))

if (files_exist) {
  cat("✓ All data files exist\n")
  
  # Run analysis
  cat("\nRunning GWAS analysis...\n")
  
  tryCatch({
    result <- KinLmSbl(
      Y = Y_file,
      GD = GD_file,
      KI = KI_file,
      CV = CV_file,
      file.output = TRUE,
      dir = getwd()
    )
    
    cat("\n✓ Analysis completed successfully!\n")
    
    # Display result summary
    if (nrow(result) > 0) {
      cat("\nFound", nrow(result), "significant SNPs\n")
      cat("\nTop 5 significant SNPs:\n")
      print(head(result, 5))
      
      cat("\nResults saved to: KinLmSbl.result.csv\n")
    } else {
      cat("\nNo significantly associated SNPs found\n")
    }
    
  }, error = function(e) {
    cat("\n✗ Error during run:\n")
    print(e)
  })
  
} else {
  cat("\n✗ Data files do not exist, please check the following files:\n")
  for (f in c(Y_file, GD_file, KI_file, CV_file)) {
    cat("  -", f, ifelse(file.exists(f), "✓", "✗"), "\n")
  }
  cat("\nSkipping test run.\n")
  cat("Please place the data files in the current directory, or modify the file paths in the script.\n")
}

# ==================================
# 5. Package information
# ==================================
cat("\nPackage information:\n")
cat("Package name: KinLmSBL\n")
cat("Version: 1.0.0\n")
cat("Description: Kinship Linear Model with Sparse Bayesian Learning for GWAS\n")

cat("\nTest completed!\n")