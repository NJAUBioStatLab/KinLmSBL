# Example Data Documentation

## Example Data Files in Current Directory

The following example data files are included in your working directory `d:\KinLmSBL_1.0.0\` and can be used directly to test the KinLmSBL package:

### 1. phenotype.csv
- **Description**: Phenotype data file
- **Format**: CSV, contains individual IDs and phenotype values
- **Purpose**: Provides phenotype data for analysis

### 2. genotype.012.csv
- **Description**: Genotype data file
- **Format**: 012-encoded SNP data
- **Column Structure**:
  - Column 1: SNP ID
  - Column 2: Chromosome 
  - Column 3: Chromosome position
  - Column 4: Refallele
  - Column 5 onwards: Genotypes for each individual (0/1/2)
- **Purpose**: Provides SNP genotype data

### 3. kinship.csv
- **Description**: Kinship matrix
- **Format**: Symmetric matrix, CSV format
- **Description**: Describes genetic relatedness between samples
- **Purpose**: Controls for polygenic background in a mixed linear model


### 4. covariates.csv

- **Description**: Covariate file 
- **Format**: CSV, contains individual IDs and principal component values
- **Purpose**: Used as fixed-effect covariates to control for population structure


## Using Example Data

### Quick Test Example

```r
# Load package
library(KinLmSBL)

# Set working directory to example data location
setwd("d:/KinLmSBL_1.0.0")

# Run analysis
result <- KinLmSbl(
  Y = "phenotype.csv",       
  GD = "genotype.012.csv",    
  KI = "kinship.csv",       
  CV = "covariates.csv",     
  file.output = TRUE,         
  dir = getwd()              
)

# View results
print(result)

# If significant SNPs are found
if (nrow(result) > 0) {
  cat("\nFound", nrow(result), "significant SNPs (FDR < 0.05)\n\n")
  print(result)
} else {
  cat("\nNo significant SNPs found\n")
}
```

## Preparing Your Own Data

If you want to use your own data, please ensure the data format is consistent with the example files:

### Phenotype Data Requirements
- CSV format
- At least 2 columns
- Column 2 contains numeric phenotype values
- No missing values (or missing values already handled)

### Genotype Data Requirements
- CSV format
- First 4 columns: SNP information (ID, Chr, Pos, Ref)
- Remaining columns: Genotype for each individual
- Encoding: 0 (reference homozygous), 1 (heterozygous), 2 (alternative homozygous)
- Sample order must be consistent with other files

### Kinship Matrix Requirements
- CSV format
- Symmetric square matrix
- Dimension = number of samples × number of samples
- Include column names (sample IDs)
- Diagonal elements typically equal to 1

### Covariate File Requirements
- CSV format
- Column 1: Sample IDs
- Remaining columns: Covariate values (usually principal components)
- Recommended to include 3-10 principal components

## Data Quality Control Recommendations

Before running the analysis, the following quality control is recommended:

1. **Phenotype Data**
   - Check for outliers
   - Standardization (optional)
   - Remove missing values

2. **Genotype Data**
   - Filter low-quality SNPs (call rate < 95%)
   - Filter low-frequency SNPs (MAF < 0.05)
   - Filter SNPs deviating from Hardy-Weinberg equilibrium

3. **Sample Quality Control**
   - Remove high-missingness samples
   - Check sample consistency
   - Ensure sample order is consistent across all files

## Common Questions

### Q: Must data files be in CSV format?
A: Yes, the current version requires CSV format. You can use Excel or R to convert other formats to CSV.

### Q: What if sample order is inconsistent?
A: You need to ensure sample order is completely consistent across all files. It's recommended to preprocess data in R.

### Q: Can there be missing genotypes?
A: The current implementation does not support missing values; imputation or deletion is required beforehand.

### Q: How to calculate the kinship matrix?
A: You can use GEMMA, GCTA, or the rMVP package to calculate the kinship matrix.

## Related R Code Examples

### Data Preprocessing Example

```r
library(data.table)

# Read data
Y <- fread("phenotype.csv")
GD <- fread("genotype.012.csv")
KI <- fread("kinship.csv")
CV <- fread("covariates.csv")

# Check dimensions
cat("Phenotype samples:", nrow(Y), "\n")
cat("Genotype SNPs:", nrow(GD), "\n")
cat("Kinship matrix dimensions:", dim(KI), "\n")
cat("Covariate samples:", nrow(CV), "\n")

# Check missing values
cat("Phenotype missing:", sum(is.na(Y)), "\n")
cat("Genotype missing:", sum(is.na(GD)), "\n")
```

---

**Note**: These example data files are for testing package functionality only. Please use your own data for actual analysis.
