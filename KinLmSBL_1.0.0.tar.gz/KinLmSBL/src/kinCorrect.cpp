// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace std;
using namespace arma;
// ys  xs  X0  Z K 
//[[Rcpp::export]]
Rcpp::List emma_maineffects_B1(arma::mat Z,arma::mat K,double deltahat_g,bool complete){
  arma::mat B;
  if( Z.has_nan() ){
    double t=K.n_rows;
    if(K.n_cols==t){
      arma::mat E1(t,t,fill::eye);
      B=deltahat_g*K+E1;
    }
  }
  else{
    double n = Z.n_rows;
    if ( complete == false ) {
      Z=Z.cols(find(sum(Z,0)>0));
      Z.print();
      K=K.submat(find(sum(Z,0)>0),find(sum(Z,0)>0));
    }
    arma::mat E2(n,n,fill::eye);
    B=deltahat_g*Z*K*Z.t()+E2;
  }
  arma::vec eigval;
  arma::mat eigvec;
  eig_sym(eigval, eigvec, B);
  arma::mat A=diagmat(1/sqrt(eigval(find(eigval>0))),0);
  arma::mat Q=eigvec.cols(find(eigval>0));
  arma::mat C=Q*A*Q.t();
  return List::create(Named("mC")=C,Named("Q")=Q);
}

