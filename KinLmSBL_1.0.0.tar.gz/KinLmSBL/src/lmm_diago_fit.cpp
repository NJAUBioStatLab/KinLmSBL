// [[Rcpp::depends(Rcpp,RcppEigen)]]
#define EIGEN_DONT_PARALLELIZE
#define EIGEN_MPL2_ONLY
#define EIGEN_DISABLE_UNALIGNED_ARRAY_ASSERT
#define EIGEN_NO_DEBUG
#define EIGEN_DONT_VECTORIZE
#include <Rcpp.h>
#include "diago2.h"
#include "diago2_nocovar.h"
#include "lmm_diago_min_max_h2.h"
#include <RcppEigen.h>
#include <Eigen/Dense>
using namespace Eigen;
using namespace Rcpp;


//[[Rcpp::export]]
List fit_diago(NumericVector Y, NumericMatrix X, IntegerVector p_, NumericVector Sigma, NumericMatrix U, double min_h2, double max_h2, double tol, double verbose, bool brent) {
  Map_MatrixXd y0(as<Map<MatrixXd> >(Y));
  Map_MatrixXd x0(as<Map<MatrixXd> >(X));
  Map<VectorXd> sigma(as<Map<VectorXd> >(Sigma));
  Map_MatrixXd u(as<Map<MatrixXd> >(U));

  MatrixXd x = u.transpose() * x0;
  MatrixXd y = u.transpose() * y0;

  int n = sigma.rows();
  int r = x.cols();  
  int max_iter = 10;

  List R;

  min_max_h2(Sigma, min_h2, max_h2);
  if(verbose) Rcout << "Optimization in interval [" << min_h2 << ", " << max_h2 << "]" << std::endl;

  for(int i = 0; i < p_.length(); i++) {
    int p = p_(i);
    if(verbose) Rcout << "Optimizing with p = " << p << "\n";
   
    // likelihood maximization 
    double h2 = min_h2;
    diag_likelihood<MatrixXd, VectorXd, double> A(p, y, x, sigma);
    if(brent) 
      h2 = A.Brent_fmax(min_h2, max_h2, tol);
    else
      A.newton_max(h2, min_h2, max_h2, tol, max_iter, verbose);

    // calcul blups transféré dans la classe diag_likelihood !...
    VectorXd beta, omega;
    A.blup(h2, beta, omega, false, false);
    double s2 = (1-h2)*A.v, tau = h2*A.v;

    // **** Calcul décomposition de la variance gardé ici (on a besoin de la matrice u)
    VectorXd Ut1 = u.transpose() * VectorXd::Ones(n);
    VectorXd Xbeta = x0 * beta.topRows(r) + u.leftCols(p) * beta.bottomRows(p) ;

    double psi1 = n*( p*s2 + tau*sigma.topRows(p).col(0).array().sum()  ); // n*trace(U1 Va U1') = n*trace(Va)
    psi1 -= Ut1.topRows(p).transpose() * ( tau*sigma.topRows(p).col(0).asDiagonal() )* Ut1.topRows(p);  // - 1' U1 Va U1' 1
    psi1 -= s2*Ut1.topRows(p).squaredNorm();
    psi1 /= n*(n-1);

    double psi2 = n*A.v*trace_of_product( A.xtx, A.XViX_i ); // n*trace(U2 Xb (...) Xb' U2')
    VectorXd zz = x.bottomRows(n-p).transpose() * Ut1.bottomRows(n-p);

    psi2 -= A.v*zz.transpose() * A.XViX_i * zz;
    psi2 /= n*(n-1);

    double SXbeta = Xbeta.array().sum();
    double varXbeta = (Xbeta.squaredNorm() - SXbeta*SXbeta/n)/(n-1) - psi1 - psi2;
    // **** fin décomposition !
  

    List L;
    L["ve"] = s2;
    L["vg"] = tau;
    L["delta"] = tau/s2;

    if(p_.length() > 1) R.push_back(L); else R = L;
  }
  return R;
}

//[[Rcpp::export]]
List fit_diago_nocovar(NumericVector Y, IntegerVector p_, NumericVector Sigma, NumericMatrix U, double min_h2, double max_h2, double tol, double verbose, double brent) {
  Map_MatrixXd y0(as<Map<MatrixXd> >(Y));
  Map<VectorXd> sigma(as<Map<VectorXd> >(Sigma));
  Map_MatrixXd u(as<Map<MatrixXd> >(U));

  MatrixXd y = u.transpose() * y0;

  int n = sigma.rows();
  int max_iter = 10;
  List R;

  min_max_h2(Sigma, min_h2, max_h2);
  if(verbose) Rcout << "Optimization in interval [" << min_h2 << ", " << max_h2 << "]" << std::endl;

  for(int i = 0; i < p_.length(); i++) {
    int p = p_(i);
    if(verbose) Rcout << "Optimizing with p = " << p << "\n";
   
    // likelihood maximization 
    double h2 = min_h2;
    diag_likelihood_nocovar<MatrixXd, VectorXd, double> A(p, y, sigma);
    if(brent) 
      h2 = A.Brent_fmax(min_h2, max_h2, tol);
    else
      A.newton_max(h2, min_h2, max_h2, tol, max_iter, verbose);

    // calcul blups transféré dans la classe diag_likelihood !...
    VectorXd beta, omega;
    A.blup(h2, beta, omega, false);
    double s2 = (1-h2)*A.v, tau = h2*A.v;

    // **** Calcul décomposition de la variance gardé ici (on a besoin de la matrice u)
    VectorXd Ut1 = u.transpose() * VectorXd::Ones(n);
    VectorXd Xbeta = u.leftCols(p) * beta.bottomRows(p) ;

    double psi1 = n*( p*s2 + tau*sigma.topRows(p).col(0).array().sum()  ); // n*trace(U1 Va U1') = n*trace(Va)
    psi1 -= Ut1.topRows(p).transpose() * ( tau*sigma.topRows(p).col(0).asDiagonal() )* Ut1.topRows(p);  // - 1' U1 Va U1' 1
    psi1 -= s2*Ut1.topRows(p).squaredNorm();
    psi1 /= n*(n-1);

    double SXbeta = Xbeta.array().sum();
    double varXbeta = (Xbeta.squaredNorm() - SXbeta*SXbeta/n)/(n-1) - psi1;
    // **** fin décomposition !
  

    List L;
    L["ve"] = s2;
    L["vg"] = tau;
    L["delta"] = tau/s2;
    
    if(p_.length() > 1) R.push_back(L); else R = L;
  }
  return R;
}

