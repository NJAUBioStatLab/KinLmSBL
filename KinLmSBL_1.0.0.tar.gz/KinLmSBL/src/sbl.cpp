#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
Rcpp::List sblgwas(const arma::mat& x, const arma::colvec& y, const arma::mat& z, double t = -1, int max_iter = 200, double min_err = 1e-6) {
  int n = y.n_rows;
  int q = x.n_cols;
  int m = z.n_cols;

  arma::colvec b0 = arma::solve(x.t() * x, x.t() * y, arma::solve_opts::likely_sympd);
  double s2 = arma::sum(arma::square(y - x * b0)) / (n - q);
  b0.zeros();

  arma::colvec b = b0;
  arma::colvec g0(m, arma::fill::zeros);
  arma::colvec g = g0;
  arma::colvec lambda(m, arma::fill::zeros);
  arma::colvec tau = g0;
  arma::colvec v = g0;

  arma::colvec xx(q), xy(q), zz(m), zy(m);

  for (int i = 0; i < q; i++) {
    xx[i] = arma::sum(arma::square(x.col(i)));
    xy[i] = arma::sum(x.col(i) % y);
  }

  for (int k = 0; k < m; k++) {
    zz[k] = arma::sum(arma::square(z.col(k)));
    zy[k] = arma::sum(z.col(k) % y);
  }

  arma::colvec d(m, arma::fill::zeros);
  arma::colvec a(n, arma::fill::zeros);

  int iter = 0;
  double err = 1e8;
  arma::mat my_iter;

  double df = 0;

  while (iter < max_iter && err > min_err) {
    for (int i = 0; i < q; i++) {
      a -= x.col(i) * b0[i];
      double ai = arma::sum(x.col(i) % a);
      b[i] = (xy[i] - ai) / xx[i];
      a += x.col(i) * b[i];
    }

    df = 0;
    for (int k = 0; k < m; k++) {
      a -= z.col(k) * g0[k];
      double ak = arma::sum(z.col(k) % a);
      double c1 = -(t + 3) * zz[k] * zz[k];
      double c2 = -(2 * t + 5) * zz[k] + (zy[k] - ak) * (zy[k] - ak);
      double c3 = -(t + 2);
      if ((c2 * c2 - 4 * c1 * c3 < 0) || (c2 < 0)) {
        tau[k] = 0;
      } else {
        tau[k] = (-c2 - std::sqrt(c2 * c2 - 4 * c1 * c3)) / (2 * c1);
      }
      lambda[k] = tau[k] / s2;
      g[k] = lambda[k] * (zy[k] - ak) - lambda[k] * lambda[k] * zz[k] * (zy[k] - ak) / (lambda[k] * zz[k] + 1);
      d[k] = lambda[k] * (zz[k] - lambda[k] * zz[k] * zz[k] / (lambda[k] * zz[k] + 1));
      v[k] = tau[k] - tau[k] * d[k];
      df += d[k];
      a += z.col(k) * g[k];
    }

    if ((n - q - df) > 0) {
      s2 = arma::sum(arma::square(y - a)) / (n - q - df);
    } else {
      s2 = arma::sum(arma::square(y - a)) / (n - q);
    }

    iter++;
    err = arma::sum(arma::square(g - g0)) / m;
    g0 = g;
    b0 = b;
    arma::rowvec iter_res = arma::join_horiz(arma::rowvec{(double)iter, err, s2}, b.t(), g.t());
    my_iter = arma::join_vert(my_iter, iter_res);
  }

  Rcpp::DataFrame my_parm = Rcpp::DataFrame::create(
    Rcpp::Named("iter") = iter,
    Rcpp::Named("error") = err,
    Rcpp::Named("s2") = s2,
    Rcpp::Named("beta") = Rcpp::wrap(b),
    Rcpp::Named("df") = df
  );

  arma::uvec posv = arma::find(v != 0);
  arma::colvec wald(m, arma::fill::zeros);
  arma::colvec gg = g.elem(posv);
  arma::colvec vv = v.elem(posv);
  wald.elem(posv) = arma::square(gg) / vv;
  
  Rcpp::NumericVector wald_nv = Rcpp::wrap(wald);
  Rcpp::NumericVector p_wald = Rcpp::pchisq(wald_nv, 1, false, false);

  Rcpp::DataFrame my_blup = Rcpp::DataFrame::create(
    Rcpp::Named("gamma") = Rcpp::wrap(g),
    Rcpp::Named("vg") = Rcpp::wrap(v),
    Rcpp::Named("wald") = Rcpp::wrap(wald),
    Rcpp::Named("p_wald") = p_wald
  );

  Rcpp::CharacterVector var_beta, var_gamma;
  for (int i = 0; i < q; i++) {
    var_beta.push_back("beta" + std::to_string(i + 1));
  }
  for (int k = 0; k < m; k++) {
    var_gamma.push_back("gamma" + std::to_string(k + 1));
  }

  Rcpp::CharacterVector var_names = Rcpp::CharacterVector::create("iter", "error", "s2");
  for (int i = 0; i < var_beta.size(); i++) {
    var_names.push_back(var_beta[i]);
  }
  for (int k = 0; k < var_gamma.size(); k++) {
    var_names.push_back(var_gamma[k]);
  }

  Rcpp::DataFrame my_iteration = Rcpp::as<Rcpp::DataFrame>(Rcpp::wrap(my_iter));
  my_iteration.attr("names") = var_names;

  return Rcpp::List::create(
    Rcpp::Named("iteration") = my_iteration,
    Rcpp::Named("parm") = my_parm,
    Rcpp::Named("blup") = my_blup
  );
}
