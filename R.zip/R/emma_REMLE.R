# From FASTmrEMMA (Wen et al., 2018) and Package gaston

emma_REMLE <- function(Y, X, eigenK, p = 0, method = c("newton", "brent"), 
                       min_h2 = 0, max_h2 = 1, 
                       verbose = getOption("gaston.verbose", TRUE), 
                       tol = .Machine$double.eps^0.25) {
  if(any(is.na(Y))) 
    stop('Missing data in Y.')
  
  if(!is.null(X)) {
    if(length(Y) < (ncol(X) + max(p))) 
      stop('The total number of covariables and PCs as fixed effects cannot exceed the number of observations.')
    if(length(Y) != nrow(X)) 
      stop('Length of Y and the number of rows of X differ.')
  } else if(length(Y) < max(p))
    stop('The total number of covariables and PCs as fixed effects cannot exceed the number of observations.')
  
  Sigma <- eigenK$values
  if(length(Y) != length(Sigma)) 
    stop('Length of Y and number of eigenvalues differ.')
  
  w <- which(Sigma < 1e-6)
  Sigma[w] <- 1e-6
  
  U <- eigenK$vectors
  
  method <- match.arg(method)
  brent <- (method == "brent") 
  if(is.null(X))
    return(fit_diago_nocovar(Y, p, Sigma, U, min_h2, max_h2, tol, verbose, brent))
  else
    return(fit_diago(Y, X, p, Sigma, U, min_h2, max_h2, tol, verbose, brent))
}
