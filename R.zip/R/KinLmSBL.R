#' KinLmSBL: A two-stage GWAS algorithm that integrates single marker scanning and sparse Bayesian learning
#'
#' @description
#' Performs a two-stage GWAS by integrating single marker scanning and sparse Bayesian learning.
#' The first stage involves constructing a single-locus mixed linear model 
#' and strategically implementing a matrix transformation for polygenic background correction. 
#' Next, general linear regression is performed to scan high-throughput markers, 
#' identifying a small number of potentially associated SNPs for the second stage. 
#' Finally, a multi-locus model is constructed, 
#' and sparse Bayesian learning is performed to identify the significant loci with false discovery rate correction. 
#' 
#' 
#' 
#' @param Y Character string. Path to the phenotype file in CSV format.
#'   The first column contains individual IDs and the second column contains phenotypic values.
#'   Individual IDs must match those in genotype, kinship and covariate files.
#'   Missing values should be coded as NA or NaN, 
#'   any missing values in the dataset should be previously preprocessed by the user.
#'
#' @param GD Character string. Path to the genotype file in CSV format using 0, 1, 2 coding.
#'   The first four columns contain SNP information including SNP ID, chromosome,
#'   position and reference allele.
#'   Remaining columns correspond to individual genotypes.
#'
#' @param KI Character string. Path to the kinship matrix file in CSV format.
#'   The kinship matrix must be square and symmetric.
#'   Row and column names must correspond to individual IDs in the phenotype file.
#'
#' @param CV Character string. Path to the covariate file in CSV format.
#'   Rows represent individuals and columns represent covariates.
#'   The individual order must be consistent with the phenotype file.
#'
#' @param file.output Logical. Whether to write GWAS results to a CSV file.
#'   Default is TRUE.
#'
#' @param dir Character string. Directory used to save output files.
#'   Default is the current working directory.
#'
#' @return
#' A data frame containing significant SNPs with the following columns:
#' \itemize{
#'   \item SNP: SNP identifier
#'   \item Chr: Chromosome 
#'   \item Pos: Position
#'   \item P.value: FDR adjusted p value
#'   \item MAF: Minor allele frequency
#'   \item r2(%): Variance explained by the SNP
#'   \item Effect: Estimated effect size
#' }
#'
#' @details
#' The analysis consists of two stages.
#' 
#' In the first stage, 
#'  it constructs a mixed linear model and corrects for the polygenic background using FASTmrEMMA's matrix transformation. 
#'  It then employs rMVP's MVP.GLM function to scan high-throughput SNPs, 
#'  screening for a small number of potentially associated SNPs for the next stage.
#'  
#' In the second stage, 
#'  it constructs a hierarchical linear model, 
#'  applies the SBL algorithm to estimate marker effects and construct the Wald test statistic, 
#'  and implements FDR correction.
#' Multiple testing is controlled using the Benjamini-Hochberg false discovery rate method.
#'
#' @references
#' Zhang et al.(2025). Integrated single marker scanning and sparse Bayesian learning
#'  improves performance of detection for GWAS
#' 
#' #'
#' @examples
#' \dontrun{
#' result <- KinLmSbl(
#'   Y  = "phenotype.csv",
#'   GD = "genotype.012.csv",
#'   KI = "kinship.csv",
#'   CV = "covariates.csv",
#'   dir = getwd()
#' )
#' }
#'
#' @export
KinLmSbl <- function(
    Y = NULL,
    GD = NULL,
    KI = NULL,
    CV = NULL,
    file.output = TRUE,
    dir = getwd() ) { 
  
  # Load required C++ functions
  # Note: These are now compiled as part of the package
  
  #Kinship
  normalized_KI <- normalizePath(KI, mustWork = FALSE)
  if (!file.exists(normalized_KI)) {
    stop("fileKI dose not exist: ", normalized_KI)
  }
  
  k <- read.table(file = KI, sep = ",", header = TRUE)
  Kinship <- matrix(unlist(k), nrow = dim(k)[1], ncol = dim(k)[2])
  
  #phenotype
  normalized_Y <- normalizePath(Y, mustWork = FALSE)
  if (!file.exists(normalized_Y)) {
    stop("fileY dose not exist: ", normalized_Y)
  }
  Phe <- data.table::fread(file = Y, showProgress = FALSE)
  yo <- Phe[, 2]
  if(is.numeric(yo) == FALSE){
    yo <- as.numeric(unlist(yo)) 
  }
  
  #Q matrix
  normalized_CV <- normalizePath(CV, mustWork = FALSE)
  if (!file.exists(normalized_CV)) {
    stop("filePS dose not exist: ", normalized_CV)
  }
  pcs <- read.table(file = normalized_CV, sep = ",", header = TRUE)
  cvs <- matrix(unlist(pcs[, -1]), nrow = dim(pcs)[1], ncol = dim(pcs)[2] - 1)
  
  #genotype  
  normalized_GD <- normalizePath(GD, mustWork = FALSE)
  if (!file.exists(normalized_GD)) {
    stop("fileGen dose not exist: ", normalized_GD)
  }
  x <- read.table(file = normalized_GD, sep = ",", header = TRUE)
  snpName2 <- x[, 1]
  gen <- t(x[, -c(1, 2, 3, 4)])
  mafVec <- colMeans(gen) / 2
  ps <- x[, 3]
  chr <- x[, 2]
  w0 <- as.matrix(rep(1, times = length(yo)))
  qq <- eigen(Kinship, symmetric = TRUE)
  pKinLm0 <- RcppEigen::fastLmPure(y = yo, X = cvs)
  if (exists("cvs") && is.numeric(cvs) && length(cvs) > 0) {
    YY <- yo - cvs %*% pKinLm0$coefficients
  } else { 
    YY <- yo 
  }
  
  # -------------------------------------------- 
  # first stage: single-locus screening using a linear mixed model
  # --------------------------------------------
  # correct the polygenic background
  remle2 <- emma_REMLE(Y = YY, X = w0, qq)
  remle1_B1 <- emma_maineffects_B1(Z = matrix(), Kinship, remle2$delta, complete = TRUE)
  C2 <- remle1_B1$mC
  Y_c <- C2 %*% YY
  
  # sparse matrix
  multiG <- function(c, geno){
    GEN <- methods::as(geno, "sparseMatrix")
    ncolx <- dim(GEN)[2]
    if(ncolx > 500000){
      G_c01 <- c %*% GEN[, 1:500000]
      G_c02 <- c %*% GEN[, 500001:dim(GEN)[2]]
      G_c00 <- cbind(G_c01, G_c02)
    } else {
      G_c00 <- c %*% GEN
    }
    G_c <- methods::as(G_c00, "matrix")
    return(G_c)
  }
  G_c <- multiG(c = C2, geno = gen)
  
  # Linear regression scan
  yName <- matrix(1:nrow(Y_c), ncol = 1)
  Y2 <- cbind(yName, Y_c)
  G_c01 <- rMVP::as.big.matrix(t(G_c))
  pKinLm01 <- rMVP::MVP.GLM(Y2, G_c01, cpu = 1, mrk_bycol = FALSE) 
  pKinLm <- pKinLm01[, 3]
  names(pKinLm) <- snpName2  
  tax <- !is.na(pKinLm)
  pKinLm <- pKinLm[tax]
  m <- dim(gen)[2]
  seqloc <- c(1:m)
  
  selectLoc0.01 <- seqloc[pKinLm < 0.01]
  snpSelect0.01 <- snpName2[selectLoc0.01]
  snpPsSelect0.01 <- ps[selectLoc0.01]
  chrSelect0.01 <- chr[selectLoc0.01]
  mafSelect0.01 <- mafVec[selectLoc0.01]
  gen0.01 <- gen[, selectLoc0.01]
  
  # -----------------------------------------
  # second stage: sparse Bayesian learning 
  # -----------------------------------------
  fit0.01 <- sblgwas(x = w0, y = YY, z = gen0.01, t = -1)
  blup0.01 <- fit0.01$blup
  sbl_pvalue <- blup0.01[, 4]
  
  # False Discovery Rate correction
  pvalue_adj <- stats::p.adjust(sbl_pvalue, method = "BH", n = length(sbl_pvalue)) 
  ids_marked <- which(pvalue_adj < 0.05)
  
  var_Y <- stats::var(yo)
  qtnIdKinlmsbl0.01 <- snpSelect0.01[pvalue_adj < 0.05] 
  qtnPsKinlmsbl0.01 <- snpPsSelect0.01[pvalue_adj < 0.05]
  chrKinlmsbl0.01 <- chrSelect0.01[pvalue_adj < 0.05]
  gamma <- blup0.01[ids_marked, 1]
  pvalue_final <- pvalue_adj[pvalue_adj < 0.05]
  maf_final <- mafSelect0.01[pvalue_adj < 0.05]
  
  # ------------------------------------------------------ 
  # output 
  # ------------------------------------------------------
  output_file <- file.path(dir, "KinLmSbl.result.csv")
  if (length(qtnIdKinlmsbl0.01) == 0) {
    message("Find no SNP!")
    result <- data.frame(
      SNP = c(), 
      Chr = c(), 
      Pos = c(), 
      P.value = c(), 
      MAF = c(),
      r2 = c(), 
      Effect = c())
    if(file.output) {
      utils::write.csv(file = output_file, result)
    }
    return(result)
  } else {
    Chr <- chrKinlmsbl0.01
    Pos <- qtnPsKinlmsbl0.01
    maf <- maf_final
    Pvalue <- format(pvalue_final, scientific = TRUE, digits = 4)
    Snp <- qtnIdKinlmsbl0.01
    Effect <- round(gamma, 4)
    r2 <- round(fit0.01$blup$vg[pvalue_adj < 0.05] / 
                  rep(var_Y, length(fit0.01$blup$vg[pvalue_adj < 0.05])) * 100, 4)
    
    result <- data.frame(
      SNP = Snp,
      Chr = Chr,
      Pos = Pos,
      P.value = Pvalue,
      MAF = maf,
      'r2(%)' = r2,
      Effect = Effect,
      check.names = FALSE
    )
    if(file.output) {
      utils::write.csv(file = output_file, result, row.names = FALSE)
    }
    return(result)
  }  
}
